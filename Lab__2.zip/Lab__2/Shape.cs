﻿using System;

namespace Lab2
{
    public class Circle : Shape
    {

        public override void Draw()
        {
            var r = 25;
            var area = Math.PI * r * r;
            Console.WriteLine($"Area of circle is {area}");
        }
    }

    public class Square : Shape
    {
        public override void Draw()
        {
            Console.WriteLine("En fyrkant");
        }
    }



    public class Shape
    {
        public int Width { get; set; }
        public int Height { get; set; }
        public Position Position { get; set; }

        public virtual void Draw()
        {

        }
    }
}