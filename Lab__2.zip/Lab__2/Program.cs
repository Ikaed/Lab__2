﻿using System.Collections.Generic;

namespace Lab2
{
    class Program
    {
        static void Main(string[] args)
        {
            var shapes = new List<Shape>();
            shapes.Add(new Circle());
            shapes.Add(new Square());

            var canvas = new Canvas();
            canvas.DrawShapes(shapes);
        }
    }
}

